#include "types.h"
#include "stat.h"
#include "user.h"

int 
main(int argc, char *argv[]){
  int second;
  if(argc<=1){
  	printf(1,"error: need more parameters\n");
  }else{
  second=atoi(argv[1]);
  sleep(100*second);
  printf(1,"(nothing happens for a little while)\n");
  }
  exit();
}


