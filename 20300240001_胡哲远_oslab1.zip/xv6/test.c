#include "types.h"
#include "stat.h"
#include "user.h"
//#include <fcntl.h>
//#include <unistd.h>

int 
main(int argc, char *argv[]){
/*
int x1=-1;
int x2=-1;
int pid=-1;
if((pid=fork())<0){//error
}else if(pid==0){//child
char bufc[8]="child\n";
x1=open("./number.txt",O_WRONLY|O_CREAT);
printf(1,"child:%d\n",x1);
int ret1=write(x1,bufc,sizeof(bufc));
printf(1,"child:%d\n",ret1);
close(x1);
}else{//parent
char bufp[8]="parent\n";
x2=open("./number.txt",O_WRONLY|O_CREAT);
printf(1,"parent:%d\n",x2);
int ret2=write(x2,bufp,sizeof(bufp));
printf(1,"parent:%d\n",ret2);
close(x2);
}
*/
exit();
}
