#include "types.h"
#include "stat.h"
#include "user.h"

int 
main(int argc, char *argv[]){
int pid=-1;
int s2p[2];
int p2s[2];
pipe(s2p);
pipe(p2s);

if((pid=fork())<0){//error
}else if(pid==0){//son
char ch_son[6];
close(p2s[1]);
read(p2s[0],ch_son,sizeof(ch_son));
printf(1,"%d: received %s\n",getpid(),ch_son);
close(p2s[0]);
close(s2p[0]);
write(s2p[1],"pong",4);
close(s2p[1]);
exit();
}else{//parent
char ch_parent[6];
close(p2s[0]);
write(p2s[1],"ping",4);
close(p2s[1]);
close(s2p[1]);
read(s2p[0],ch_parent,sizeof(ch_parent));
close(s2p[0]);
printf(1,"%d: received %s\n",getpid(),ch_parent);
exit();
}
exit();
}
