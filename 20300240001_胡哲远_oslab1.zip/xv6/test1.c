#include "types.h"
#include "stat.h"
//#include "user.h"
#include <sys/wait.h>
#include <unistd.h>
#include <stdio.h>

int 
main(int argc, char *argv[]){
int pid=-1;
int i=0;
if((pid=fork())<0){//error
}else if(pid==0){//child
int * status=&i;
int x=waitpid(pid,status,0);
printf("child:%d\n",x);
}else{//parent
int * status=&i;
int x=waitpid(pid,status,0);
printf("parent:%d\n",x);
}
return 0;
}
